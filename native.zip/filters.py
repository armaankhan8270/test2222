# filters.py
import datetime as dt
from typing import Tuple, Dict, Optional

class DateFilterHandler:
    """
    Handles date range conversions for SQL queries
    Converts filter keywords to date ranges
    """
    
    DATE_FORMAT = "%Y-%m-%d"
    
    @staticmethod
    def get_date_range(filter_key: str) -> Tuple[str, str]:
        """
        Convert date filter keyword to SQL-compatible date range
        
        Args:
            filter_key: Date range key (7d, 30d, 3m, etc)
        
        Returns:
            Tuple of (start_date, end_date) in ISO format
        """
        today = dt.date.today()
        
        ranges = {
            "7d": (today - dt.timedelta(days=7), today),
            "30d": (today - dt.timedelta(days=30), today),
            "3m": (today - dt.timedelta(days=90), today),
            "6m": (today - dt.timedelta(days=180), today),
            "1y": (today - dt.timedelta(days=365), today),
            "ytd": (dt.date(today.year, 1, 1), today),
            "all": (dt.date(2000, 1, 1), today)
        }
        
        if filter_key not in ranges:
            raise ValueError(f"Invalid date filter: {filter_key}. Valid options: {list(ranges.keys())}")
        
        start_date, end_date = ranges[filter_key]
        return start_date.strftime(DateFilterHandler.DATE_FORMAT), end_date.strftime(DateFilterHandler.DATE_FORMAT)
    
    @staticmethod
    def apply_filters(query: str, date_range: str, user_id: Optional[str] = None) -> str:
        """
        Apply date and user filters to SQL query
        
        Args:
            query: SQL query template
            date_range: Date range keyword
            user_id: Optional user ID filter
        
        Returns:
            Formatted SQL query
        """
        start_date, end_date = DateFilterHandler.get_date_range(date_range)
        
        # Add date filter
        query = query.replace("{{date_filter}}", 
                             f"AND START_TIME BETWEEN '{start_date}' AND '{end_date}'")
        
        # Add user filter if provided
        if user_id:
            query = query.replace("{{user_filter}}", 
                                 f"AND USER_NAME = '{user_id}'")
        else:
            query = query.replace("{{user_filter}}", "")
            
        return query