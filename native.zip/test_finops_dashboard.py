# test_finops_dashboard.py
import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from datetime import datetime, timedelta

# Mock Snowpark session class to simulate real behavior
class MockSession:
    @staticmethod
    def sql(query: str):
        class MockResult:
            @staticmethod
            def to_pandas():
                # Parse query type from mock query string
                if "TOTAL_SPEND" in query:
                    return pd.DataFrame({"TOTAL_SPEND": [np.random.randint(5000, 20000)]})
                elif "AVG_TIME" in query:
                    return pd.DataFrame({"AVG_TIME": [np.random.randint(100, 500)]})
                elif "TOTAL_QUERIES" in query:
                    return pd.DataFrame({"TOTAL_QUERIES": [np.random.randint(10000, 50000)]})
                elif "STORAGE_COST" in query:
                    return pd.DataFrame({"STORAGE_COST": [np.random.uniform(200, 800)]})
                elif "USER_NAME" in query:
                    users = [f"user_{i}" for i in range(1, 11)]
                    costs = np.random.randint(100, 5000, size=10)
                    return pd.DataFrame({"USER_NAME": users, "TOTAL_COST": costs})
                elif "QUERY_COUNT" in query:
                    dates = [datetime.now() - timedelta(days=i) for i in range(30, 0, -1)]
                    counts = np.random.poisson(200, 30)
                    return pd.DataFrame({"DAY": dates, "QUERY_COUNT": counts})
                elif "WAREHOUSE_NAME" in query:
                    warehouses = ["WH_SMALL", "WH_MEDIUM", "WH_LARGE", "WH_XL"]
                    credits = np.random.randint(100, 2000, 4)
                    avg_times = np.random.randint(500, 5000, 4)
                    return pd.DataFrame({
                        "WAREHOUSE_NAME": warehouses, 
                        "CREDITS": credits,
                        "AVG_TIME": avg_times
                    })
                elif "MINUTES" in query:
                    queries = [
                        "SELECT * FROM large_table JOIN...", 
                        "WITH complex_cte AS (...)",
                        "INSERT INTO summary_table...",
                        "CREATE TABLE temp_analysis...",
                        "UPDATE user_profiles SET..."
                    ]
                    minutes = np.random.randint(10, 120, 5)
                    return pd.DataFrame({
                        "QUERY_TEXT": queries,
                        "MINUTES": minutes
                    })
                elif "AVG_STORAGE_GB" in query:
                    dates = [datetime.now() - timedelta(days=i*30) for i in range(12, 0, -1)]
                    storage = np.cumsum(np.random.randint(100, 500, 12))
                    return pd.DataFrame({
                        "USAGE_DATE": dates,
                        "AVG_STORAGE_GB": storage
                    })
                return pd.DataFrame()
        return MockResult()

# Date Filter Handler (Same as original)
class DateFilterHandler:
    DATE_FORMAT = "%Y-%m-%d"
    
    @staticmethod
    def get_date_range(filter_key: str) -> tuple[str, str]:
        today = datetime.today().date()
        ranges = {
            "7d": (today - timedelta(days=7), today),
            "30d": (today - timedelta(days=30), today),
            "3m": (today - timedelta(days=90), today),
            "6m": (today - timedelta(days=180), today),
            "1y": (today - timedelta(days=365), today),
        }
        start_date, end_date = ranges.get(filter_key, ranges["30d"])
        return start_date.strftime(DATE_FORMAT), end_date.strftime(DATE_FORMAT)

# Query Store with Mock Support
class QueryStore:
    def __init__(self, session):
        self.session = session
        self._queries = {
            "total_spend": "SELECT TOTAL_SPEND FROM MOCK",
            "avg_query_time": "SELECT AVG_TIME FROM MOCK",
            "total_queries": "SELECT TOTAL_QUERIES FROM MOCK",
            "storage_cost": "SELECT STORAGE_COST FROM MOCK",
            "cost_by_user": "SELECT USER_NAME, TOTAL_COST FROM MOCK",
            "queries_over_time": "SELECT DAY, QUERY_COUNT FROM MOCK",
            "warehouse_usage": "SELECT WAREHOUSE_NAME, CREDITS, AVG_TIME FROM MOCK",
            "long_running_queries": "SELECT QUERY_TEXT, MINUTES FROM MOCK",
            "storage_growth": "SELECT USAGE_DATE, AVG_STORAGE_GB FROM MOCK"
        }
    
    @st.cache_data(ttl=60)
    def run_query(_self, key: str, date_range: str = "30d", user_id: str = None):
        try:
            if key not in _self._queries:
                raise ValueError(f"Invalid query key: {key}")
                
            # For demo: Print mock query being "executed"
            print(f"Executing mock query: {key}")
            
            return _self.session.sql(_self._queries[key]).to_pandas()
        except Exception as e:
            st.error(f"Query failed: {str(e)}")
            return pd.DataFrame()

# Chart Renderer (Same as original)
class ChartRenderer:
    THEME = {
        "bar": px.colors.sequential.Blues,
        "line": px.colors.sequential.Teal,
        "pie": px.colors.sequential.RdBu,
        "area": px.colors.sequential.deep,
        "treemap": px.colors.sequential.Sunset
    }
    
    def __init__(self, query_store: QueryStore):
        self.query_store = query_store
        
    def render(self, key: str, chart_type: str, title: str, 
               date_range: str = "30d", user_id: str = None, **kwargs):
        df = self.query_store.run_query(key, date_range, user_id)
        if df.empty:
            st.warning(f"No data for: {title}")
            return
        
        fig = self._create_figure(df, chart_type, title, **kwargs)
        st.plotly_chart(fig, use_container_width=True)
    
    def _create_figure(self, df, chart_type: str, title: str, **kwargs):
        if chart_type == "bar":
            return px.bar(df, title=title, color_discrete_sequence=self.THEME["bar"], **kwargs)
        elif chart_type == "line":
            return px.line(df, title=title, color_discrete_sequence=self.THEME["line"], **kwargs)
        elif chart_type == "pie":
            return px.pie(df, title=title, hole=0.3, color_discrete_sequence=self.THEME["pie"], **kwargs)
        elif chart_type == "area":
            return px.area(df, title=title, color_discrete_sequence=self.THEME["area"], **kwargs)
        elif chart_type == "treemap":
            return px.treemap(df, title=title, color_discrete_sequence=self.THEME["treemap"], **kwargs)
        raise ValueError(f"Unsupported chart type: {chart_type}")

# Metric Renderer (Same as original)
class MetricCardRenderer:
    ICONS = {"spend": "💰", "time": "⏱️", "queries": "📊", "storage": "💾", "default": "✅"}
    
    def __init__(self, query_store: QueryStore):
        self.query_store = query_store
        
    def render(self, key: str, label: str, icon: str = "default", 
              date_range: str = "30d", user_id: str = None, **kwargs):
        df = self.query_store.run_query(key, date_range, user_id)
        if df.empty:
            st.metric(label=label, value="N/A")
            return
            
        value = df.iloc[0, 0]
        formatted_value = self._format_value(value, **kwargs)
        display_icon = self.ICONS.get(icon, self.ICONS["default"])
        st.metric(label=f"{display_icon} {label}", value=formatted_value)
    
    def _format_value(self, value, prefix="", suffix="", precision=2):
        if isinstance(value, float):
            return f"{prefix}{value:.{precision}f}{suffix}"
        return f"{prefix}{value}{suffix}"

# Demo Dashboard Page
def main():
    st.set_page_config(page_title="FinOps Dashboard Demo", layout="wide")
    st.title("📊 Snowflake FinOps Dashboard (Mock Demo)")
    st.caption("Using simulated data - No Snowflake connection required")
    
    # Initialize with mock session
    mock_session = MockSession()
    query_store = QueryStore(mock_session)
    chart_renderer = ChartRenderer(query_store)
    metric_renderer = MetricCardRenderer(query_store)
    
    # Filters
    with st.sidebar:
        st.header("Filters")
        date_range = st.selectbox("Date Range", ["7d", "30d", "3m", "6m", "1y"], index=1)
        user_id = st.text_input("User ID (Optional)", "admin@company.com")
    
    # Metrics
    cols = st.columns(4)
    with cols[0]:
        metric_renderer.render("total_spend", "Total Spend", "spend", date_range, prefix="$", precision=0)
    with cols[1]:
        metric_renderer.render("avg_query_time", "Avg Query Time", "time", date_range, suffix="ms")
    with cols[2]:
        metric_renderer.render("total_queries", "Total Queries", "queries", date_range)
    with cols[3]:
        metric_renderer.render("storage_cost", "Storage Cost", "storage", date_range, prefix="$", precision=2)
    
    st.divider()
    
    # Charts
    col1, col2 = st.columns(2)
    with col1:
        chart_renderer.render(
            "cost_by_user", "bar", "Cost by User", date_range, user_id,
            x="USER_NAME", y="TOTAL_COST"
        )
        chart_renderer.render(
            "warehouse_usage", "treemap", "Warehouse Usage", date_range, user_id,
            path=["WAREHOUSE_NAME"], values="CREDITS"
        )
    
    with col2:
        chart_renderer.render(
            "queries_over_time", "line", "Queries Over Time", date_range, user_id,
            x="DAY", y="QUERY_COUNT"
        )
        chart_renderer.render(
            "storage_growth", "area", "Storage Growth", date_range,
            x="USAGE_DATE", y="AVG_STORAGE_GB"
        )
    
    # Full-width chart
    chart_renderer.render(
        "long_running_queries", "bar", "Long Running Queries", date_range, user_id,
        x="MINUTES", y="QUERY_TEXT", orientation="h", height=400
    )
    
    st.info("This is a fully functional demo using mock data. "
            "Replace MockSession with real Snowpark session to connect to Snowflake.")

if __name__ == "__main__":
    main()