# chart_renderer.py
import streamlit as st
import plotly.express as px
from typing import Optional, Dict
from query_store import QueryStore

class ChartRenderer:
    """
    Generates Plotly charts from query results
    Supports multiple chart types with consistent styling
    """
    
    THEME = {
        "bar": px.colors.sequential.Blues,
        "line": px.colors.sequential.Teal,
        "pie": px.colors.sequential.RdBu,
        "area": px.colors.sequential.deep,
        "treemap": px.colors.sequential.Sunset
    }
    
    def __init__(self, query_store: QueryStore):
        """
        Initialize with QueryStore instance
        
        Args:
            query_store: Preconfigured QueryStore
        """
        self.query_store = query_store
        
    def render(self, key: str, chart_type: str, title: str, 
               date_range: str = "7d", user_id: Optional[str] = None, **kwargs):
        """
        Render chart from query results
        
        Args:
            key: Query identifier
            chart_type: Type of chart (bar, line, pie, etc)
            title: Chart title
            date_range: Date range filter
            user_id: Optional user filter
            kwargs: Additional chart customization
        """
        df = self.query_store.run_query(key, date_range, user_id)
        if df is None or df.empty:
            st.warning(f"No data available for: {title}")
            return
        
        try:
            fig = self._create_figure(df, chart_type, title, **kwargs)
            st.plotly_chart(fig, use_container_width=True)
        except Exception as e:
            st.error(f"Chart rendering failed: {str(e)}")
    
    def _create_figure(self, df, chart_type: str, title: str, **kwargs):
        """Create Plotly figure based on chart type"""
        if chart_type == "bar":
            return self._create_bar(df, title, **kwargs)
        elif chart_type == "line":
            return self._create_line(df, title, **kwargs)
        elif chart_type == "pie":
            return self._create_pie(df, title, **kwargs)
        elif chart_type == "area":
            return self._create_area(df, title, **kwargs)
        elif chart_type == "treemap":
            return self._create_treemap(df, title, **kwargs)
        else:
            raise ValueError(f"Unsupported chart type: {chart_type}")
    
    def _create_bar(self, df, title: str, x: str, y: str, **kwargs):
        return px.bar(
            df, x=x, y=y, title=title, 
            color_discrete_sequence=self.THEME["bar"],
            **kwargs
        ).update_layout(yaxis_title=None, xaxis_title=None)
    
    def _create_line(self, df, title: str, x: str, y: str, **kwargs):
        return px.line(
            df, x=x, y=y, title=title,
            color_discrete_sequence=self.THEME["line"],
            **kwargs
        ).update_layout(yaxis_title=None, xaxis_title=None)
    
    def _create_pie(self, df, title: str, names: str, values: str, **kwargs):
        return px.pie(
            df, names=names, values=values, title=title,
            color_discrete_sequence=self.THEME["pie"],
            hole=0.3, **kwargs
        )
    
    def _create_area(self, df, title: str, x: str, y: str, **kwargs):
        return px.area(
            df, x=x, y=y, title=title,
            color_discrete_sequence=self.THEME["area"],
            **kwargs
        ).update_layout(yaxis_title=None, xaxis_title=None)
    
    def _create_treemap(self, df, title: str, path: list, values: str, **kwargs):
        return px.treemap(
            df, path=path, values=values, title=title,
            color_discrete_sequence=self.THEME["treemap"],
            **kwargs
        )