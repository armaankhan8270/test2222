# metric_renderer.py
import streamlit as st
from query_store import QueryStore
from typing import Optional

class MetricCardRenderer:
    """
    Renders KPI metric cards from query results
    Handles formatting and value extraction
    """
    
    ICONS = {
        "spend": "💰",
        "time": "⏱️",
        "queries": "📊",
        "storage": "💾",
        "default": "✅"
    }
    
    def __init__(self, query_store: QueryStore):
        """
        Initialize with QueryStore instance
        
        Args:
            query_store: Preconfigured QueryStore
        """
        self.query_store = query_store
        
    def render(self, key: str, label: str, icon: str = "default", 
              date_range: str = "7d", user_id: Optional[str] = None, **kwargs):
        """
        Render metric card from query results
        
        Args:
            key: Query identifier
            label: Card title
            icon: Icon key (spend, time, etc)
            date_range: Date range filter
            user_id: Optional user filter
            kwargs: Formatting options (prefix, suffix, precision)
        """
        df = self.query_store.run_query(key, date_range, user_id)
        if df is None or df.empty:
            st.metric(label=label, value="N/A")
            return
            
        value = self._extract_value(df)
        if value is None:
            st.metric(label=label, value="N/A")
            return
            
        formatted_value = self._format_value(value, **kwargs)
        display_icon = self.ICONS.get(icon, self.ICONS["default"])
        
        st.metric(label=f"{display_icon} {label}", value=formatted_value)
    
    def _extract_value(self, df):
        """Extract single value from first row/column"""
        try:
            return df.iloc[0, 0]
        except (IndexError, KeyError):
            return None
    
    def _format_value(self, value, prefix: str = "", suffix: str = "", precision: int = 2):
        """Format numerical values for display"""
        if isinstance(value, float):
            value = f"{value:.{precision}f}"
        return f"{prefix}{value}{suffix}"