# user_360_page.py
import streamlit as st
from query_store import QueryStore
from chart_renderer import ChartRenderer
from metric_renderer import MetricCardRenderer
from mock_config import session
# Initialize session and components
query_store = QueryStore(session)
chart_renderer = ChartRenderer(query_store)
metric_renderer = MetricCardRenderer(query_store)

# Page configuration
st.set_page_config(page_title="Snowflake FinOps Dashboard", layout="wide")
st.title("❄️ Snowflake FinOps Analytics")
st.markdown("### User 360° Performance & Cost Analysis")

# Filters sidebar
with st.sidebar:
    st.header("Filters")
    date_range = st.selectbox("Date Range", ["7d", "30d", "3m", "6m", "1y", "ytd"], index=1)
    user_id = st.text_input("User ID (Optional)")

# Metrics row
col1, col2, col3, col4 = st.columns(4)
with col1:
    metric_renderer.render("total_spend", "Total Spend", "spend", date_range, user_id, prefix="$", precision=0)
with col2:
    metric_renderer.render("avg_query_time", "Avg Query Time", "time", date_range, user_id, suffix="ms", precision=0)
with col3:
    metric_renderer.render("total_queries", "Total Queries", "queries", date_range, user_id)
with col4:
    metric_renderer.render("storage_cost", "Storage Cost", "storage", date_range, prefix="$", precision=2)

# Charts section
st.markdown("---")
col_left, col_right = st.columns(2)

with col_left:
    chart_renderer.render(
        "cost_by_user", "bar", "Cost by User", date_range, user_id,
        x="USER_NAME", y="TOTAL_COST"
    )
    
    chart_renderer.render(
        "warehouse_usage", "treemap", "Warehouse Usage", date_range, user_id,
        path=["WAREHOUSE_NAME"], values="CREDITS"
    )

with col_right:
    chart_renderer.render(
        "queries_over_time", "line", "Queries Over Time", date_range, user_id,
        x="DAY", y="QUERY_COUNT"
    )
    
    chart_renderer.render(
        "storage_growth", "area", "Storage Growth", date_range,
        x="USAGE_DATE", y="AVG_STORAGE_GB"
    )

# Full-width chart
chart_renderer.render(
    "long_running_queries", "bar", "Longest Running Queries", date_range, user_id,
    x="MINUTES", y="QUERY_TEXT", orientation="h", height=400
)