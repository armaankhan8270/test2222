# mock_config.py
from unittest.mock import MagicMock
import pandas as pd

class MockSession:
    def sql(self, query):
        # Return self so .to_pandas() works
        return self
    def to_pandas(self):
        # Return a fixed DataFrame similar to expected query results
        return pd.DataFrame({
            "user_name": ["user1", "user2"],
            "total_credits": [100.0, 200.0],
            "date": ["2023-06-01", "2023-06-02"],
            "query_count": [10, 15],
            "total_spend": [500, 600],
            "execution_time": [1000, 500],
            "warehouse_name": ["WH1", "WH2"],
            "usage_date": ["2023-06-01", "2023-06-02"],
            "total_storage": [1000, 1200]
        })

session = MockSession()
