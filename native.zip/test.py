# Example usage on new page
from query_store import QueryStore
from chart_renderer import ChartRenderer
from metric_renderer import MetricCardRenderer
from mock_config import session
# Initialize once
query_store = QueryStore(session)
chart_renderer = ChartRenderer(query_store)
metric_renderer = MetricCardRenderer(query_store)

# Render metric
metric_renderer.render("total_spend", "Total Cost", date_range="30d")

# Render chart
chart_renderer.render("cost_by_user", "bar", "User Costs", date_range="30d")