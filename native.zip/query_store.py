# query_store.py
import streamlit as st
from snowflake.snowpark import Session
from typing import Dict, Any, Optional
from filters import DateFilterHandler

class QueryStore:
    """
    Centralized query storage and execution with caching
    Uses key-value store for SQL queries with templating
    """
    
    def __init__(self, session: Session):
        """
        Initialize with Snowpark session
        
        Args:
            session: Active Snowpark session
        """
        self.session = session
        self._queries = self._load_query_templates()
        self.cache = {}
        
    def _load_query_templates(self) -> Dict[str, str]:
        """
        Define all SQL queries for the FinOps dashboard
        
        Returns:
            Dictionary of query templates
        """
        return {
            # KPI Queries
            "total_spend": """
                SELECT SUM(CREDITS_USED * CREDIT_PRICE) AS TOTAL_SPEND 
                FROM METERING_HISTORY 
                WHERE 1=1
                {{date_filter}}
                {{user_filter}}
            """,
            
            "avg_query_time": """
                SELECT AVG(EXECUTION_TIME) AS AVG_TIME 
                FROM QUERY_HISTORY 
                WHERE 1=1
                {{date_filter}}
                {{user_filter}}
            """,
            
            "total_queries": """
                SELECT COUNT(*) AS TOTAL_QUERIES 
                FROM QUERY_HISTORY 
                WHERE 1=1
                {{date_filter}}
                {{user_filter}}
            """,
            
            "storage_cost": """
                SELECT SUM(STORAGE_BYTES * STORAGE_COST_PER_TB / 1e12) AS STORAGE_COST 
                FROM STORAGE_USAGE 
                WHERE 1=1
                {{date_filter}}
            """,
            
            # Chart Queries
            "cost_by_user": """
                SELECT USER_NAME, SUM(CREDITS_USED * CREDIT_PRICE) AS TOTAL_COST
                FROM METERING_HISTORY 
                WHERE 1=1
                {{date_filter}}
                {{user_filter}}
                GROUP BY USER_NAME
                ORDER BY TOTAL_COST DESC
                LIMIT 20
            """,
            
            "queries_over_time": """
                SELECT DATE_TRUNC('DAY', START_TIME) AS DAY,
                       COUNT(*) AS QUERY_COUNT
                FROM QUERY_HISTORY 
                WHERE 1=1
                {{date_filter}}
                {{user_filter}}
                GROUP BY DAY
                ORDER BY DAY
            """,
            
            "warehouse_usage": """
                SELECT WAREHOUSE_NAME, 
                       SUM(CREDITS_USED) AS CREDITS,
                       AVG(EXECUTION_TIME) AS AVG_TIME
                FROM METERING_HISTORY
                WHERE 1=1
                {{date_filter}}
                {{user_filter}}
                GROUP BY WAREHOUSE_NAME
            """,
            
            "long_running_queries": """
                SELECT QUERY_TEXT, USER_NAME, EXECUTION_TIME/60000 AS MINUTES 
                FROM QUERY_HISTORY 
                WHERE EXECUTION_TIME > 300000
                {{date_filter}}
                {{user_filter}}
                ORDER BY EXECUTION_TIME DESC 
                LIMIT 10
            """,
            
            "storage_growth": """
                SELECT USAGE_DATE, 
                       AVERAGE_STORAGE_BYTES / (1024^3) AS AVG_STORAGE_GB
                FROM STORAGE_USAGE
                WHERE 1=1
                {{date_filter}}
                ORDER BY USAGE_DATE
            """
        }
    
    @st.cache_data(ttl=3600, show_spinner="Running optimized Snowflake query...")
    def run_query(_self, key: str, date_range: str = "7d", user_id: Optional[str] = None) -> Any:
        """
        Execute query with caching and return Pandas DataFrame
        
        Args:
            key: Query identifier
            date_range: Date range filter key
            user_id: Optional user filter
            
        Returns:
            Query result as Pandas DataFrame
        """
        if key not in _self._queries:
            raise KeyError(f"Query '{key}' not found in QueryStore")
            
        raw_query = _self._queries[key]
        formatted_query = DateFilterHandler.apply_filters(raw_query, date_range, user_id)
        
        try:
            return _self.session.sql(formatted_query).to_pandas()
        except Exception as e:
            st.error(f"❌ Query failed: {str(e)}")
            st.code(formatted_query)
            return None